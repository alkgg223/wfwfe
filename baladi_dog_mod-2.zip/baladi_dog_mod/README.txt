Baladi Dog mod - Minecraft 1.21.1 / NeoForge 21.1.264
Build: copy the gradlew files from the official NeoForge 1.21.1 MDK into this folder, then run: ./gradlew build
Jar output: build/libs/baladi_dog-1.0.0.jar
